# This file is auto-generated.  Do not edit.

hex_file_name = 'AT90USB1286_16MHz_FULLSIZE.hex'
device = 'AT90USB1286'
speed = '16MHz'
size = 'FULLSIZE'

layers_map = 0x00000c35
actions_map = 0x0000070d
tapkeys_map = 0x000001e5
macro_map = 0x0000115d
led_layers_map = 0x000001e0
num_leds_map = 0x000032c9
num_ind_map = 0x000032c8
led_hw_map = 0x00003298
led_map = 0x0000326e
num_bl_enab_map = 0x0000326d
bl_mask_map = 0x0000325d
bl_mode_map = 0x0000315d
strobe_cols_map = 0x00003389
strobe_low_map = 0x00003388
num_strobe_map = 0x00003387
num_sense_map = 0x00003386
matrix_init_map = 0x0000337a
matrix_strobe_map = 0x000032f6
matrix_sense_map = 0x000032ca
kmac_key_map = None
pw_defs_map = 0x0000338a
boot_ptr_map = 0x00003b49
prod_str_map = 0x00003cca
