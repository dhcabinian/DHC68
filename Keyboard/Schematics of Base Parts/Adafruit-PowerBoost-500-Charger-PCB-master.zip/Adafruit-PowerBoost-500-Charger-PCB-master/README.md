Adafruit-PowerBoost-500-Charger-PCB
=================================

PCB files for the Adafruit PowerBoost 500 Charger

Pick up one today at 

----> https://www.adafruit.com/product/1944

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution